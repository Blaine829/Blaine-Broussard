#ifndef __A09_H__
#define __A09_H__

#include <string>

using std::string;

// Returns the string with leading/trailing whitespace removed
string trim(string const& str);

// Returns true if the character is a digit
bool isDigit(char c);

// Returns true if the character is +-*/
bool isOperator(char c);

// Returns an integer representing the precedence of the operator,
// where higher values are higher precedence
int precedence(char c);



//*****************************************************************
//                          FUNDAMENTALS
//*****************************************************************

// Returns the infix representation of the given postfix
// arithmetic expression of integers.
string convertInfixToPostfix(string infix);


//*****************************************************************
//                          PROFICIENCY
//*****************************************************************

// Returns the evaluated solution to the postfix arithmetic expression.
int evaluatePostfix(string postfix);



#endif
