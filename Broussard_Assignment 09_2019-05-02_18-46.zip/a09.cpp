#include "a09.h"
#include <stack>
#include <sstream>
#include <cmath>
using std::stack;
using std::stringstream;

#include <iostream>
using std::cout;
using std::endl;

std::string trim(std::string const& str) {
    if (str.empty()) return str;
    std::size_t firstScan = str.find_first_not_of(' ');
    std::size_t first = firstScan ==
                        std::string::npos ? str.length() : firstScan;
    std::size_t last = str.find_last_not_of(' ');
    return str.substr(first, last-first+1);
}

bool isDigit(char c) {
    return c >= '0' && c <= '9';
}

bool isOperator(char c) {
    return c == '+' || c == '-' || c == '*' || c == '/' || c == '^';
}

int precedence(char c) {
    switch (c) {
        case '^':
            return 4;
        case '/':
        case '*':
            return 3;
        case '+':
        case '-':
            return 2;
        case '(':
        case ')':
            return 1;
        default:
            return 0;
    }
}

string convertInfixToPostfix(string infix) {
    infix = "(" + infix + ")";
    string postfix = "";
    stack<char> s;
    string temp = "";
    for (int i = 0; i < infix.size(); i++) {
        if (isDigit(infix[i])) {
            temp = temp + infix[i];
        } else {
            if (temp.size() > 0) {
                postfix = postfix + temp + " ";
                temp = "";
            }
            if (infix[i] == '(') {
                s.push(infix[i]);
            } else if (infix[i] == ')') {
                char p = s.top();
                s.pop();
                while (p != '(') {
                    postfix = postfix + p + " ";
                    p = s.top();
                    s.pop();
                }
            } else if (isOperator(infix[i])) {
                while (s.size() > 0 && precedence(s.top()) >=
                precedence(infix[i])) {
                    postfix = postfix + s.top() + " ";
                    s.pop();
                }
                s.push(infix[i]);
            }
        }
    }
    if (temp.size() > 0) {
        postfix = postfix + temp + " ";
    }
    while (s.size() > 0) {
        postfix = postfix + s.top() + " ";
        s.pop();
    }
    return trim(postfix);
}

int evaluatePostfix(string postfix) {
    stringstream sstr(postfix);
    stack<int> eval;
    string temp1 = "";
    while (sstr) {
        string input;
        sstr >> input;
        if (input.size() > 1) {
            int value = stoi(input);
            eval.push(value);
        } else if (isDigit(input[0])) {
            int value = stoi(input);
            eval.push(value);
        } else if (isOperator(input[0])) {
            if (input == "+") {
                int first = eval.top();
                eval.pop();
                int second = eval.top();
                eval.pop();
                eval.push(first + second);
            } else if (input == "-") {
                int first = eval.top();
                eval.pop();
                int second = eval.top();
                eval.pop();
                eval.push(second - first);
            } else if (input == "/") {
                int first = eval.top();
                eval.pop();
                int second = eval.top();
                eval.pop();
                eval.push(second / first);
            } else if (input == "*") {
                int first = eval.top();
                eval.pop();
                int second = eval.top();
                eval.pop();
                eval.push(first * second);
            } else if (input == "^") {
                int first = eval.top();
                eval.pop();
                int second = eval.top();
                eval.pop();
                eval.push(pow(second, first));
            }
        }
    }
    return eval.top();
}
