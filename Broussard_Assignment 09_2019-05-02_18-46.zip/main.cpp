#include <iostream>
#include "a09.h"

using std::cout;
using std::endl;


void testConversion(string infix, string postfix) {
    string p = convertInfixToPostfix(infix);
    cout << ((p == postfix)? "(SUCCESS)" : "(FAILURE)");
    cout << "  '" << infix << "' to postfix";
    cout << "  ['" << postfix << "' == '" << p << "']" << endl;
}

int main() {
    cout << evaluatePostfix("5 2 3 ^ * 4 + 13 2 - / 3 2 1 + ^ +") << endl;
    testConversion("2 * 5", "2 5 *");
    testConversion("(9 - 5) / 2 + 7", "9 5 - 2 / 7 +");
    testConversion("(12 + 3) * (10 - 14) + 2", "12 3 + 10 14 - * 2 +");
    testConversion("5 * 2 ^ 3 + 4) / (13 - 2) + 3 ^ (2 + 1", "5 2 3 ^ * 4 + 13 2 - / 3 2 1 + ^ +");

    return 0;
}
