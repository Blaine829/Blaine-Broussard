#include "a03.h"
#include <cmath>
#include <array>
#include <string>
#include <iostream>
using std::cout;
using std::endl;
using std::fabs;


float calcWeightedAverage(float grades[], float weights[], int n) {
    float total_weights = 0;
    float grades_times_weight = 0;
    float weighted_average;
    for (int a = 0; a < n; a = a + 1) {
        total_weights = total_weights + weights[a];
        grades_times_weight += grades[a] * weights[a];
    weighted_average = (grades_times_weight / total_weights);
    }
    if (fabs(total_weights - 1.0) < 0.0001) {
        return weighted_average;
    } else {
        return -1;
    }
}
