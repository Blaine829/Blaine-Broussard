#ifndef __A03_H__
#define __A03_H__


float calcWeightedAverage(float grades[], float weights[], int n);


#endif
