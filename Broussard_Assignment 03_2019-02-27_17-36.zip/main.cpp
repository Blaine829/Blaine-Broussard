#include <iostream>
#include "a03.h"

using std::cout;
using std::endl;


int main() {
    const int N = 6;
    float grades[N];
    float weights[N];
    float badweights[N];
    for (int i = 0; i < N; i++) {
        grades[i] = 10 * (i + 1);
        weights[i] = 1.0 / N;
        badweights[i] = weights[i];
    }
    badweights[0] = 0;

    float average = calcWeightedAverage(grades, weights, N);
    if (average >= 34.99 && average <= 35.01) {
        cout << "(SUCCESS)  Average  [35 == ";
    } else {
        cout << "(FAILURE)  Average  [35 == ";
    }
    cout << average << "]" << endl;

    float badavg = calcWeightedAverage(grades, badweights, N);
    if (badavg >= -1.01 && badavg <= -0.99) {
        cout << "(SUCCESS)  Bad Average  [-1 == ";
    } else {
        cout << "(FAILURE)  Bad Average  [-1 == ";
    }
    cout << badavg << "]" << endl;

    return 0;
}
