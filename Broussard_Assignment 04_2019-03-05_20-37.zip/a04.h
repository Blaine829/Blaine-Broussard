#ifndef __A04_H__
#define __A04_H__

#include <string>

using std::string;


enum Type { PAWN, KNIGHT, BISHOP, ROOK, QUEEN, KING };
enum Rank { R1, R2, R3, R4, R5, R6, R7, R8 };
enum File { Fa, Fb, Fc, Fd, Fe, Ff, Fg, Fh };

inline Rank charToRank(char c) { return static_cast<Rank>(c - '1'); }
inline File charToFile(char c) { return static_cast<File>(c - 'a'); }
inline char rankToChar(Rank r) { return static_cast<char>(r + '1'); }
inline char fileToChar(File f) { return static_cast<char>(f + 'a'); }


struct Location {
    Rank rank;
    File file;
    Location() : rank(R1), file(Fa) {}
    Location(Rank r, File f) : rank(r), file(f) {}
};

struct Move {
    Type type;
    Location from;
    Location to;
    bool capture;
    bool check;
    Move() : type(PAWN), capture(false), check(false) {}
    Move(Type t, Location floc, Location tloc, bool cap, bool chk) {
        type = t;
        from = floc;
        to = tloc;
        capture = cap;
        check = chk;
    }
};


Move convertFromNotation(string notation);
string convertToNotation(Move move);



#endif
