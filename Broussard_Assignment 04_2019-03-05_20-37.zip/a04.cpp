#include "a04.h"


Move convertFromNotation(string notation) {
    Move move;
    int start = 0;
    if (notation[start] == 'B') {
        move.type = BISHOP;
    } else if (notation[start] == 'N') {
        move.type = KNIGHT;
    } else if (notation[start] == 'R') {
        move.type = ROOK;
    } else if (notation[start] == 'Q') {
        move.type = QUEEN;
    } else if (notation[start] == 'K') {
        move.type = KNIGHT;
    } else {
        move.type = PAWN;
        start = start - 1;
    }
    if (notation[start + 1] == 'a') {
        move.from.file = Fa;
    } else if (notation[start + 1] == 'b') {
        move.from.file = Fb;
    } else if (notation[start + 1] == 'c') {
        move.from.file = Fc;
    } else if (notation[start + 1] == 'd') {
        move.from.file = Fd;
    } else if (notation[start + 1] == 'e') {
        move.from.file = Fe;
    } else if (notation[start + 1] == 'f') {
        move.from.file = Ff;
    } else if (notation[start + 1] == 'g') {
        move.from.file = Fg;
    } else if (notation[start + 1] == 'h') {
        move.from.file = Fh;
    }
    if (notation[start + 2] == '1') {
        move.from.rank = R1;
    } else if (notation[start + 2] == '2') {
        move.from.rank = R2;
    } else if (notation[start + 2] == '3') {
        move.from.rank = R3;
    } else if (notation[start + 2] == '4') {
        move.from.rank = R4;
    } else if (notation[start + 2] == '5') {
        move.from.rank = R5;
    } else if (notation[start + 2] == '6') {
        move.from.rank = R6;
    } else if (notation[start + 2] == '7') {
        move.from.rank = R7;
    } else if (notation[start + 2] == '8') {
        move.from.rank = R8;
    }
    if (notation[start + 3] == 'x') {
        move.capture = true;
    } else if (notation[start + 3] == '-') {
        move.capture = false;
    }
    if (notation[start + 4] == 'a') {
        move.to.file = Fa;
    } else if (notation[start + 4] == 'b') {
        move.to.file = Fb;
    } else if (notation[start + 4] == 'c') {
        move.to.file = Fc;
    } else if (notation[start + 4] == 'd') {
        move.to.file = Fd;
    } else if (notation[start + 4] == 'e') {
        move.to.file = Fe;
    } else if (notation[start + 4] == 'f') {
        move.to.file = Ff;
    } else if (notation[start + 4] == 'g') {
        move.to.file = Fg;
    } else if (notation[start + 4] == 'h') {
        move.to.file = Fh;
    }
    if (notation[start + 5] == '1') {
        move.to.rank = R1;
    } else if (notation[start + 5] == '2') {
        move.to.rank = R2;
    } else if (notation[start + 5] == '3') {
        move.to.rank = R3;
    } else if (notation[start + 5] == '4') {
        move.to.rank = R4;
    } else if (notation[start + 5] == '5') {
        move.to.rank = R5;
    } else if (notation[start + 5] == '6') {
        move.to.rank = R6;
    } else if (notation[start + 5] == '7') {
        move.to.rank = R7;
    } else if (notation[start + 5] == '8') {
        move.to.rank = R8;
    }
    if (notation[start + 6] == '+') {
        move.check = true;
    } else {
        move.check = false;
    }
    return move;
}
string convertToNotation(Move move) {
    string s = "";
    if (move.type == BISHOP) {
        s = s + 'B';
    } else if (move.type == KNIGHT) {
        s = s + 'N';
    } else if (move.type == ROOK) {
        s = s + 'R';
    } else if (move.type == QUEEN) {
        s = s + 'Q';
    } else if (move.type == KING) {
        s = s + 'K';
    } else if (move.type == PAWN) {
        s = s;
    }
    if (move.from.file == Fa) {
        s = s + 'a';
    } else if (move.from.file == Fb) {
        s = s + 'b';
    } else if (move.from.file == Fc) {
        s = s + 'c';
    } else if (move.from.file == Fd) {
        s = s + 'd';
    } else if (move.from.file == Fe) {
        s = s + 'e';
    } else if (move.from.file == Ff) {
        s = s + 'f';
    } else if (move.from.file == Fg) {
        s = s + 'g';
    } else if (move.from.file == Fh) {
        s = s + 'h';
    }
    if (move.from.rank == R1) {
        s = s + "1";
    } else if (move.from.rank == R2) {
        s = s + "2";
    } else if (move.from.rank == R3) {
        s = s + "3";
    } else if (move.from.rank == R4) {
        s = s + "4";
    } else if (move.from.rank == R5) {
        s = s + "5";
    } else if (move.from.rank == R6) {
        s = s + "6";
    } else if (move.from.rank == R7) {
        s = s + "7";
    } else if (move.from.rank == R8) {
        s = s + "8";
    }
    if (move.capture == true) {
        s = s + "x";
    } else if (move.capture == false) {
        s = s + "-";
    }
    if (move.to.file == Fa) {
        s = s + 'a';
    } else if (move.to.file == Fb) {
        s = s + 'b';
    } else if (move.to.file == Fc) {
        s = s + 'c';
    } else if (move.to.file == Fd) {
        s = s + 'd';
    } else if (move.to.file == Fe) {
        s = s + 'e';
    } else if (move.to.file == Ff) {
        s = s + 'f';
    } else if (move.to.file == Fg) {
        s = s + 'g';
    } else if (move.to.file == Fh) {
        s = s + 'h';
    }
    if (move.to.rank == R1) {
        s = s + "1";
    } else if (move.to.rank == R2) {
        s = s + "2";
    } else if (move.to.rank == R3) {
        s = s + "3";
    } else if (move.to.rank == R4) {
        s = s + "4";
    } else if (move.to.rank == R5) {
        s = s + "5";
    } else if (move.to.rank == R6) {
        s = s + "6";
    } else if (move.to.rank == R7) {
        s = s + "7";
    } else if (move.to.rank == R8) {
        s = s + "8";
    }
    if (move.check == true) {
        s = s + "+";
    }
    return s;
}
