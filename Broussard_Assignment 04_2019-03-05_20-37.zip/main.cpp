#include <iostream>
#include "a04.h"

using std::cin;
using std::cout;
using std::endl;


int main() {
    Move movem[] = { Move(PAWN,
                          Location(R2, Ff),
                          Location(R4, Ff),
                          false, false),
                     Move(PAWN,
                          Location(R7, Fe),
                          Location(R5, Fe),
                          false, false),
                     Move(PAWN,
                          Location(R4, Ff),
                          Location(R5, Fe),
                          true, false),
                     Move(PAWN,
                          Location(R7, Fd),
                          Location(R6, Fd),
                          false, false),
                     Move(PAWN,
                          Location(R5, Fe),
                          Location(R6, Fd),
                          true, false),
                     Move(BISHOP,
                          Location(R8, Ff),
                          Location(R6, Fd),
                          true, false),
                     Move(PAWN,
                          Location(R2, Fg),
                          Location(R3, Fg),
                          false, false),
                     Move(QUEEN,
                          Location(R8, Fd),
                          Location(R5, Fg),
                          false, false),
                     Move(KNIGHT,
                          Location(R1, Fg),
                          Location(R3, Ff),
                          false, false),
                     Move(QUEEN,
                          Location(R5, Fg),
                          Location(R3, Fg),
                          true, true),
                     Move(PAWN,
                          Location(R2, Fh),
                          Location(R3, Fg),
                          true, false),
                     Move(BISHOP,
                          Location(R6, Fd),
                          Location(R3, Fg),
                          true, true) };

    string moves[] = { "f2-f4", "e7-e5", "f4xe5", "d7-d6",
                       "e5xd6", "Bf8xd6", "g2-g3", "Qd8-g5",
                       "Ng1-f3", "Qg5xg3+", "h2xg3", "Bd6xg3+" };

    for (int i = 0; i < 12; i++) {
        Move m = convertFromNotation(moves[i]);
        string fails = "";
        if (m.type != movem[i].type) {
            fails += "type,";
        }
        if (m.from.rank != movem[i].from.rank
         || m.from.file != movem[i].from.file) {
            fails += "from,";
        }
        if (m.to.rank != movem[i].to.rank
         || m.to.file != movem[i].to.file) {
            fails += "to,";
        }
        if (m.capture != movem[i].capture) {
            fails += "capture,";
        }
        if (m.check != movem[i].check) {
            fails += "check,";
        }
        if (fails.length() > 0) {
            cout << "(FAILURE [" << fails << "])";
        } else {
            cout << "(SUCCESS)";
        }
        cout << "  Converting \"" << moves[i] << "\" from notation" << endl;

        string s = convertToNotation(movem[i]);
        if (s == moves[i]) {
            cout << "(SUCCESS)";
        } else {
            cout << "(FAILURE)";
        }
        cout << "  Converting that correct move back to notation [";
        cout << moves[i] << " == " << s << "]" << endl;
    }

    return 0;
}
