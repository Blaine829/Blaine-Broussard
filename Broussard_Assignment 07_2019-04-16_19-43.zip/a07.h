#ifndef __A07_H__
#define __A07_H__


struct Node {
    int data;
    Node* next;
    explicit Node(int elt) { data = elt; next = nullptr; }
};


//*****************************************************************
//                          FUNDAMENTALS
//*****************************************************************

void insert(Node*& head, int value, int position);



//*****************************************************************
//                          PROFICIENCY
//*****************************************************************

bool remove(Node*& head, int value);



//*****************************************************************
//                            MASTERY
//*****************************************************************

bool duplicate(Node*& head, int value, int times);


#endif
