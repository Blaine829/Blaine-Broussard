#include "a07.h"
#include <iostream>
using namespace std;


//*****************************************************************
//                          FUNDAMENTALS
//*****************************************************************

void insert(Node*& head, int value, int position) {
    Node* p = nullptr;
    Node* t = head;
    t = head;
    int index = 0;
    while (t != nullptr && index < position) {
        p = t;
        t = t->next;
        index++;
    }
    if (position == index) {
        Node* h = new Node(value);
        if (p == nullptr) {
            h->next = t;
            head = h;
        } 
        else {
            Node* h = new Node(value);
            p->next = h;
            h->next = t;
        }
    }
}    


//*****************************************************************
//                          PROFICIENCY
//*****************************************************************

bool remove(Node*& head, int value) {
    Node* t = head;
    Node* p = nullptr;
    while (t != nullptr) {
        if (t->data == value) {
            if (p == nullptr) {
                delete t;
                head = t->next;
                return true;
            } else {
                Node* h = t->next;
                p->next = h;
                delete t;
                return true;
            }
        } else { 
            p = t;
            t = t->next;
        }
    }
    return false;

}

//*****************************************************************
//                            MASTERY
//*****************************************************************

bool duplicate(Node*& head, int value, int times) {
    Node* t = head;
    int num = 0;
    Node* p = nullptr;
    while (t != nullptr) {
        if (t->data == value) {
            if (p == nullptr) {
                while (num < times) {
                    Node* h = new Node(value);
                    h->next = t;
                    head = h;
                    t = h;
                    num = num + 1;
                }
            } else {
                while (num < times) {
                    Node* h = new Node(value);
                    p->next = h;
                    h->next = t;
                    p = h;
                    num = num + 1;
                
            }
            }
            return true;
        } else {
            p = t;
            t = t->next;
        }
    }
    return false;
}

