#include <iostream>
#include <vector>
#include "a07.h"
using std::cout;
using std::endl;
using std::vector;


int main() {
    /*
    Node* head = new Node(8);
    head->next = new Node(6);
    head->next->next = new Node(7);
    head->next->next->next = new Node(5);
    head->next->next->next->next = new Node(3);
    Node* tmp;
    int i;
    bool same = true;

    if (same) {
        vector<int> e = { 8, 6, 7, 4, 5, 3 };
        insert(head, 4, 3);
        same = true;
        tmp = head;
        i = 0;
        while (tmp != nullptr && i < e.size()) {
            if (tmp->data != e[i]) {
                same = false;
            }
            tmp = tmp->next;
            i++;
        }
        if (tmp != nullptr || i < e.size()) {
            cout << "(FAILURE)  insert(head, 4, 3)  wrong list length" << endl;
        } else if (!same) {
            cout << "(FAILURE)  insert(head, 4, 3)  wrong list contents";
            cout << endl;
        } else {
            cout << "(SUCCESS)  insert(head, 4, 3)" << endl;
        }
    }

    if (same) {
        vector<int> e = { 8, 6, 7, 4, 5, 3, 0 };
        insert(head, 0, 6);
        same = true;
        tmp = head;
        i = 0;
        while (tmp != nullptr && i < e.size()) {
            if (tmp->data != e[i]) {
                same = false;
            }
            tmp = tmp->next;
            i++;
        }
        if (tmp != nullptr || i < e.size()) {
            cout << "(FAILURE)  insert(head, 0, 6)  wrong list length" << endl;
        } else if (!same) {
            cout << "(FAILURE)  insert(head, 0, 6)  wrong list order" << endl;
        } else {
            cout << "(SUCCESS)  insert(head, 0, 6)" << endl;
        }
    }

    if (same) {
        vector<int> e = { 2, 8, 6, 7, 4, 5, 3, 0 };
        insert(head, 2, 0);
        same = true;
        tmp = head;
        i = 0;
        while (tmp != nullptr && i < e.size()) {
            if (tmp->data != e[i]) {
                same = false;
            }
            tmp = tmp->next;
            i++;
        }
        if (tmp != nullptr || i < e.size()) {
            cout << "(FAILURE)  insert(head, 2, 0)  wrong list length" << endl;
        } else if (!same) {
            cout << "(FAILURE)  insert(head, 2, 0)  wrong list order" << endl;
        } else {
            cout << "(SUCCESS)  insert(head, 2, 0)" << endl;
        }
    }
    */
    

    Node* head = new Node(8);
    head->next = new Node(6);
    head->next->next = new Node(7);
    head->next->next->next = new Node(5);
    head->next->next->next->next = new Node(3);
    
    
    
    insert (head, 4, 3);
    Node* t = head; 
    while (t != nullptr) {
        cout << t->data << endl;
        t = t->next; 
    }
    
    
    
    Node* tmp;
    while (head != nullptr) {
        tmp = head;
        head = head->next;
        delete tmp;
    }
    return 0;
}
