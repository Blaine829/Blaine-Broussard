#ifndef __A10_H__
#define __A10_H__


#include <list>

using std::list;


struct BNode {
    // This structure represents a node of a binary tree containing integers.
    int data;
    BNode* left;
    BNode* right;

    // Creating a new node sets the data to 0
    // or to the value passed in to the constructor.
    BNode() : data(0), left(nullptr), right(nullptr) {}
    explicit BNode(int n) : data(n), left(nullptr), right(nullptr) {}
};


//*****************************************************************
//                          FUNDAMENTALS
//*****************************************************************

list<int> preorderTraversal(BNode* root);
list<int> inorderTraversal(BNode* root);
list<int> postorderTraversal(BNode* root);


//*****************************************************************
//                          PROFICIENCY
//*****************************************************************

list<int> breadthFirstTraversal(BNode* root);
list<int> depthFirstTraversal(BNode* root);


//*****************************************************************
//                            MASTERY
//*****************************************************************

// Returns true if the given tree at root has the Binary Search Tree
// order property (left value is less than or equal to the node value;
// right value is greater than the node value).
bool isBinarySearchTree(BNode* root);


#endif
