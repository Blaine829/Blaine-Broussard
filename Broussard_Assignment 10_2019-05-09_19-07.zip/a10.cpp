#include "a10.h"
#include <queue>
#include <stack>
#include <iostream>
using std::queue;
using std::cout;
using std::endl;
using std::stack;

//*****************************************************************
//                          FUNDAMENTALS
//*****************************************************************

void preorderTraversalHelper(BNode* root, list<int>& lst) {
    if (root != nullptr) {
        lst.push_back(root->data);
        preorderTraversalHelper(root->left, lst);
        preorderTraversalHelper(root->right, lst);
    }
}
void postorderTraversalHelper(BNode* root, list<int>& lst) {
    if (root != nullptr) {
        postorderTraversalHelper(root->left, lst);
        postorderTraversalHelper(root->right, lst);
        lst.push_back(root->data);
    }
}

void inorderTraversalHelper(BNode* root, list<int>& lst) {
    if (root != nullptr) {
        inorderTraversalHelper(root->left, lst);
        lst.push_back(root->data);
        inorderTraversalHelper(root->right, lst);
    }
}

list<int> preorderTraversal(BNode* root) {
    list<int> lst;
    preorderTraversalHelper(root, lst);
    return lst;
}

list<int> inorderTraversal(BNode* root) {
    list<int> lst;
    inorderTraversalHelper(root, lst);
    return lst;
}

list<int> postorderTraversal(BNode* root) {
    list<int> lst;
    postorderTraversalHelper(root, lst);
    return lst;
}

//*****************************************************************
//                          PROFICIENCY
//*****************************************************************

list<int> breadthFirstTraversal(BNode* root) {
    list<int> lst;
    queue<BNode*> data;
    data.push(root);
    if (root == nullptr) {
        return lst;
    } else {
        while (!data.empty()) {
            if (data.front() != nullptr) {
                int element = data.front()->data;
                lst.push_back(element);
                data.push(data.front()->left);
                data.push(data.front()->right);
                data.pop();
            } else {
                data.pop();
            }
        }
        return lst;
    }
}

list<int> depthFirstTraversal(BNode* root) {
    list<int> lst;
    stack<BNode*> data;
    data.push(root);
    if (root == nullptr) {
        return lst;
    } else {
        while (!data.empty()) {
            if (data.top() != nullptr) {
                BNode* p = data.top();
                data.pop();
                int element = p->data;
                lst.push_back(element);
                data.push(p->right);
                data.push(p->left);
            } else {
                data.pop();
            }
        }
        return lst;
    }
}

//*****************************************************************
//                            MASTERY
//*****************************************************************

int min(BNode* root) {
    BNode* tmp = root;
    int value = 0;
    while (tmp != nullptr) {
        value = tmp->data;
        tmp = tmp->left;
    }
    return value;
}
int max(BNode* root) {
    BNode* tmp = root;
    int value = 0;
    while (tmp != nullptr) {
        value = tmp->data; 
        tmp = tmp->right;
    }
    return value;
}

bool isBinarySearchTree(BNode* root) {
    /*
    while (root != nullptr) {
        if (max(root->left >= root->data) {
            return false;
        } else if (root->left->data <= root->data) {
            return false;
        }
        root = root->left;
    }
    while (root != nullptr) {
        if (min(root->right) <= root->data) {
            return false;
        } else if (root->left->data <= root->data)
    }
    
    */
    
    if (root == nullptr) {
        return true;
    }
    if (root->left != nullptr && max(root->left) > root->data) {
        return false;
    }
    if (root->right != nullptr && min(root->right) < root->data) {
        return false;
    }
    if (!isBinarySearchTree(root->left) || !isBinarySearchTree(root->right)) {
        return false;
    }

    return true;
    
}
    

        
    /*
    } else if (root->left == nullptr && root->right != nullptr) {
        if (root->right >= root) {
            isBinarySearchTree(root->right->left);
            isBinarySearchTree(root->right->right);
            final_result = true;
        } else {
            final_result = false;
        }
    
    } else if (root->right == nullptr && root->left != nullptr) {
        if (root->left <= root) {
            isBinarySearchTree(root->left->left);
            isBinarySearchTree(root->left->right);
            final_result = true;
        } else {
            final_result = false;
        }
        
    } else if (root->right == nullptr && root->left == nullptr) {
            final_result = true;
            
    } else {
        if (root->left->data <= root->data && root->right->data >= root->data) {
            final_result = isBinarySearchTree(root->left);
            final_result = isBinarySearchTree(root->right);
        } else {
            final_result = false;
        }
        final_result = true;
    }
    */


