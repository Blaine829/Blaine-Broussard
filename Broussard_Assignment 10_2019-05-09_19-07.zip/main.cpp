#include <iostream>
#include <string>
#include <sstream>
#include "a10.h"

using std::cout;
using std::endl;
using std::string;

string listToString(list<int> lst) {
    std::stringstream str;
    for (list<int>::iterator it = lst.begin(); it != lst.end(); ++it) {
        str << *it << ",";
    }
    string s = str.str();
    s.pop_back();
    return s;
}

void deallocateTree(BNode* &root) {
    while (root != nullptr) {
        deallocateTree(root->left);
        deallocateTree(root->right);
        delete root;
        root = nullptr;
    }
}

int main() {
    /*
                    8
            6               9
        5       7       3       10
      2  10   3  8               
    
    */

    BNode* root = new BNode(8);
    root->left = new BNode(6);
    root->right = new BNode(7);
    root->left->left = new BNode(5);
    root->left->right = new BNode(3);
    root->right->left = new BNode(0);
    root->right->right = new BNode(9);
    root->left->left->left = new BNode(4);
    root->left->right->left = new BNode(1);
    root->right->left->right = new BNode(2);
    
    BNode* root1 = new BNode(8);
    root1->left = new BNode(6);
    root1->right = new BNode(9);
    root1->left->left = new BNode(5);
    root1->left->right = new BNode(7);
    root1->right->left = new BNode(3);
    root1->right->right = new BNode(10);
    root1->left->left->left = new BNode(2);
    root1->left->left->right = new BNode(10);
    root1->left->right->left = new BNode(3);
    root1->left->right->right = new BNode(8);

    BNode* nullroot = nullptr;
    
    BNode* root2 = new BNode(8);
    root2->left = nullptr;
    root2->right = new BNode(9);
    
    BNode* root3 = new BNode(8);
    root3->right = nullptr;
    root3->left = new BNode(4);
    
    BNode* root4 = new BNode(8);
    root4->right = nullptr;
    root4->left = nullptr;
    
    BNode* root5 = new BNode(8);
    root5->right = nullptr;
    root5->left = new BNode(10);
    
    string pre = "8,6,5,4,3,1,7,0,2,9";
    list<int> preorder = preorderTraversal(root);
    cout << ((listToString(preorder) == pre)? "(SUCCESS)" : "(FAILURE)");
    cout << "  Preorder";
    cout << "  [" << pre << " == " << listToString(preorder) << "]" << endl;

    string post = "4,5,1,3,6,2,0,9,7,8";
    list<int> postorder = postorderTraversal(root);
    cout << ((listToString(postorder) == post)? "(SUCCESS)" : "(FAILURE)");
    cout << "  Postorder";
    cout << "  [" << post << " == " << listToString(postorder) << "]" << endl;

    string in = "4,5,6,1,3,8,0,2,7,9";
    list<int> inorder = inorderTraversal(root);
    cout << ((listToString(inorder) == in)? "(SUCCESS)" : "(FAILURE)");
    cout << "  Inorder";
    cout << "  [" << in << " == " << listToString(inorder) << "]" << endl;
    
    if (!isBinarySearchTree(root1)) {
        cout << "Case 1 true works" << endl;
    }
    if (isBinarySearchTree(root)) {
        cout << "Case 2 false works" << endl;
    } 
    if (isBinarySearchTree(nullroot)) {
        cout << "Case 3 true works" << endl;
    }
    if (isBinarySearchTree(root2)) {
        cout << "Case 4 true works" << endl;
    }
    if (isBinarySearchTree(root3)) {
        cout << "Case 5 true works" << endl;
    }
    if (isBinarySearchTree(root4)) {
        cout << "Case 6 true works" << endl;
    }
    if (isBinarySearchTree(root5)) {
        cout << "Case 7 false works" << endl;
    }
    deallocateTree(root);
    deallocateTree(root1);
    deallocateTree(root2);
    deallocateTree(nullroot);
    deallocateTree(root3);
    deallocateTree(root4);
    deallocateTree(root5);

    return 0;
}
