#include "p03.h"
#include <fstream>
#include <iostream>
using std::cout;
using std::endl;
using std::ifstream;


//*****************************************************************
//                          FUNDAMENTALS
//*****************************************************************

Node* loadList(string filename) {
    ifstream infile;
    infile.open(filename);
    Node* head = nullptr;
    Node* t = nullptr;
    while (!infile.eof()) {
        Student s;
        int snum;
        infile >> s.id >> s.firstname >> s.lastname >> s.state >> snum >> s.gpa;
        if (snum == 1) {
            s.standing = FR;
        } else if (snum == 2) {
            s.standing = SO;
        } else if (snum == 3) {
            s.standing = JR;
        } else if (snum == 4) {
            s.standing = SR;
        }
        if (head == nullptr) {
            head = new Node;
            head->next = nullptr;
            head->data = s;
            t = head;
        } else {
            t->next = new Node;
            t = t->next;
            t->next = nullptr;
            t->data = s;
        }
    }
    return head;
}
void destroyList(Node*& head) {
    Node* p = nullptr;
    while (head != nullptr) {
        p = head;
        head = head->next;
        delete p;
        p = head;
    }
}
vector<string> getAllIds(Node* head) {
    vector<string> v;
    Node* t = head;
    while (t != nullptr) {
        v.push_back(t->data.id);
        t = t->next;
    }
    return v;
}
vector<string> getIdsForLastname(Node* head, string lastname) {
    vector<string> v;
    Node* t = head;
    while (t != nullptr) {
        if (t->data.lastname == lastname) {
            v.push_back(t->data.id);
        }
        t = t->next;
    }
    return v;
}
vector<string> getIdsForGpaStanding(Node* head, float gpa, Standing standing) {
    vector<string> v;
    Node* t = head;
    while (t != nullptr) {
        if (t->data.gpa >= gpa && t->data.standing == standing) {
            v.push_back(t->data.id);
        }
        t = t->next;
    }
    return v;
}
vector<string> getIdsForStandingState(Node* head,
    Standing standing, string state) {
    vector<string> v;
    Node* t = head;
    while (t != nullptr) {
        if (t->data.standing == standing && t->data.state == state) {
            v.push_back(t->data.id);
        }
        t = t->next;
    }
    return v;
}
//*****************************************************************
//                          PROFICIENCY
//*****************************************************************
void updateGpa(Node* head, vector<string> ids, vector<float> gpas) {
    Node* t = head;
    while (t != nullptr) {
        for (int num = 0; num < ids.size(); num++) {
            if (t->data.id == ids[num]) {
                t->data.gpa = gpas[num];
            }
        }
        t = t->next;
    }
}
//*****************************************************************
//                            MASTERY
//*****************************************************************

vector<string> getFirstLastNames(Node* head, vector<string> ids) {
    vector<string> v;
    for (int num = 0; num < ids.size(); num++) {
        Node* t = head;
        while (t != nullptr) {
            if (t->data.id == ids[num]) {
                v.push_back(t->data.firstname + " " + t->data.lastname);
                t = nullptr;
            } else {
                t = t->next;
            }
        }
    }
    return v;
}
