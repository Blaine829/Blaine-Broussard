#include <iostream>
#include <fstream>
#include "a06.h"

using std::cout;
using std::endl;
using std::ifstream;
using std::string;


void testFunctionIsRecursive(string functionName) {
    string code;
    ifstream codefile("a06.cpp");
    codefile.seekg(0, std::ios::end);
    code.reserve(codefile.tellg());
    codefile.seekg(0, std::ios::beg);
    code.assign((std::istreambuf_iterator<char>(codefile)),
                std::istreambuf_iterator<char>());
    int first = code.find(functionName);
    int second = code.find(functionName, first + 1);
    if (second < first) {
        cout << functionName << " is NOT recursive.    (FAIL)";
    } else {
        cout << functionName << " is recursive.     (SUCCESS)";
    }
    cout << endl;
}


void testCountEvenDigits(int expected, int number) {
    int a = countEvenDigits(number);
    if (a == expected) {
        cout << "(SUCCESS)";
    } else {
        cout << "(FAILURE)";
    }
    cout << "  Number of even digits of " << number << "  ";
    cout << "[" << expected << " == " << a << "]" << endl;
}


void testCountNegatives(int expected, float* f, int n) {
    int a = countNegatives(f, n);
    if (a == expected) {
        cout << "(SUCCESS)";
    } else {
        cout << "(FAILURE)";
    }
    cout << "  Number of negatives in ";
    for (int i = 0; i < n; i++) {
        cout << f[i] << " ";
    }
    cout << " [" << expected << " == " << a << "]" << endl;
}


int main() {
    float f[] = { 1.2, 4.3, -2.2, -6.8, 2.0, -5.1, 9.7, 8.4 };
    testCountNegatives(3, f, 8);

    float g[] = { 1, 2, 3, 4, 5, 6 };
    testCountNegatives(0, g, 6);

    float h[] = { -1, -2, -3, -4, -5, -6, -7, -8, -9 };
    testCountNegatives(9, h, 9);
    testFunctionIsRecursive("countNegatives");

    testCountEvenDigits(2, 1234);
    testCountEvenDigits(0, 35793);
    testCountEvenDigits(8, 24628628);
    testFunctionIsRecursive("countEvenDigits");
    /*
    float m[] = {59.4, 60.5, 80.0, 32.0, 59.5, 60.7};
    int num;
    cout << getPassingGrades(m, 6, num) << endl;
    cout << num << endl;
    */
    return 0;
}
