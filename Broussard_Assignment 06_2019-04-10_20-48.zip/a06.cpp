#include "a06.h"
#include <iostream>
#include <fstream>
#include "a06.h"

using std::cout;
using std::endl;
using std::ifstream;
using std::string;

//*****************************************************************
//                          FUNDAMENTALS
//*****************************************************************

// Returns the number of even digits in the number.
// The number is assumed to be non-negative as a precondition.
int countEvenDigits(int number) {

    if (number < 10) {
        if (number % 2 == 0) {
            return 1;
        } else {
            return 0;
        }
    } else {
        int x = countEvenDigits(number / 10);
        int last_digit = number % 10;
        if (last_digit % 2 == 0) {
            return x + 1;
        } else {
            return x;
        }
    }
}


// Returns the number of negative entries in the values array.
int countNegatives(float* values, int n) {
    if (n == 1) {
        if (values[0] < 0) {
            return 1;
        } else {
            return 0;
        }
    } else {
        int x = countNegatives(values, n - 1);
        if (values[n - 1] < 0) {
            return x + 1;
        } else {
            return x;
        }
    }
 
}


//*****************************************************************
//                          PROFICIENCY
//*****************************************************************

// Returns the sum of all grades in the array that are passing (at or
// above 59.5). It also fills the numPassingGrades parameter with the
// count of how many grades are passing. (This parameter is passed by
// reference so that the value it holds can be set inside the function
// and reflected out to the caller.)
float sumPassingGrades(float* grades, int numGrades, int& numPassingGrades) {
    if (numGrades == 1) {
        numPassingGrades = 0;
        if (grades[0] >= 59.5) {
            numPassingGrades = numPassingGrades + 1;
            return grades[0];
        } else {
            numPassingGrades = numPassingGrades + 0;
            return 0;
        }
    
    } else {
        float x = sumPassingGrades(grades, numGrades - 1, numPassingGrades);
        if (grades[numGrades - 1] >= 59.5) {
            numPassingGrades = numPassingGrades + 1;
            return x + grades[numGrades - 1];
        } else {
            numPassingGrades = numPassingGrades;
            return x;
        }
    }
    
    
}


//*****************************************************************
//                            MASTERY
//*****************************************************************

// Returns an array containing all grades from the original array that
// are passing (at or above 59.5). It also fills the numPassingGrades
// parameter with the count of how many grades are passing. (This parameter
// is passed by reference so that the value it holds can be set inside the
// function and reflected out to the caller.)
float* getPassingGrades(float* grades, int numGrades, int& numPassingGrades) {
    if (numGrades == 0) {
        numPassingGrades = 0;
        return nullptr;
    } else {
        float* array;
        array = getPassingGrades(grades, numGrades - 1, numPassingGrades);
        if (grades[numGrades - 1] >= 59.5) {
            float* array_1 = new float[numPassingGrades];
            for (int num = 0; num < numPassingGrades; num++) {
                array_1[num] = array[num];
            }
            array_1[numPassingGrades] = grades[numGrades - 1];
            delete [] array;
            numPassingGrades ++;
            return array_1;
    
        } 
        else {
            return array;
        }
    }
}

