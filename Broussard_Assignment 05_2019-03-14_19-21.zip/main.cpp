#include <iostream>
#include "a05.h"

using std::cout;
using std::endl;


int main() {
    int v1[10] = {3, 3, 1, 2, 1, 4, 1, 3, 1, 4};
    int v2[10] = {4, 3, 1, 4, 1, 4, 3, 1, 4, 4};
    Exam e = loadExamFromFile("input.txt");
    cout << "From input.txt..." << endl;
    if (e.numQuestions == 10) {
        cout << "(SUCCESS)";
    } else {
        cout << "(FAILURE)";
    }
    cout << "  Number of questions [10 == " << e.numQuestions << "]" << endl;
    for (int i = 0; i < e.numQuestions; i++) {
        if (e.correct[i] == v1[i]) {
            cout << "(SUCCESS)";
        } else {
            cout << "(FAILURE)";
        }
        cout << "  Question " << (i + 1) << " correct  [" << v1[i];
        cout << " == " << e.correct[i] << "]" << endl;

        if (e.response[i] == v2[i]) {
            cout << "(SUCCESS)";
        } else {
            cout << "(FAILURE)";
        }
        cout << "  Question " << (i + 1) << " response [" << v2[i];
        cout << " == " << e.response[i] << "]" << endl;
    }
    cout << endl;
    int grade = getNumCorrect(e);
    if (grade == 5) {
        cout << "(SUCCESS)";
    } else {
        cout << "(FAILURE)";
    }
    cout << "  Number of correct responses [5 == " << grade << "]" << endl;
    cout << endl;

    delete [] e.correct;
    delete [] e.response;


    return 0;
}












