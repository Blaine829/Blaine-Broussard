#ifndef __A05_H__
#define __A05_H__

#include <string>

using std::string;


struct Exam {
    int numQuestions;
    int* correct;
    int* response;
};


//*****************************************************************
//                          FUNDAMENTALS
//*****************************************************************
Exam loadExamFromFile(string filename);
int getNumCorrect(const Exam& exam);


//*****************************************************************
//                          PROFICIENCY
//*****************************************************************
float maximumScore(Exam* exams, int numExams);



#endif
