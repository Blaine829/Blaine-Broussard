#include "a05.h"
#include <fstream>
#include <string>
#include <iostream>
using std::iostream;
using std::ifstream;
using std::cout;
using std::endl;
Exam loadExamFromFile(string filename) {
    Exam exam;
    ifstream infile;
    infile.open(filename);
    int ch = 0;
    int hc = 0;
    infile >> exam.numQuestions;
    exam.correct = new int[exam.numQuestions];
    exam.response = new int[exam.numQuestions];
    for (int line = 0; line < exam.numQuestions; line++) {
        infile >> ch;
        exam.correct[line] = ch;
    }
    for (int num = 0; num < exam.numQuestions; num++) {
        infile >> hc;
        exam.response[num] = hc;
    }
    infile.close();
    return exam;
}
int getNumCorrect(const Exam& exam) {
    int num_correct = 0;
    for (int line = 0; line < exam.numQuestions; line++) {
        if (exam.correct[line] == exam.response[line]) {
            num_correct = num_correct + 1;
        }
    }
    return num_correct;
}
float maximumScore(Exam* exams, int numExams) {
    float examScore = 0;
    float percentage = 0;
    for (int numb = 0; numb < numExams; numb++) {
        examScore = (getNumCorrect(exams[numb])/
                     static_cast<float>(exams[numb].numQuestions)) *
                    100;
        if (examScore > percentage) {
            percentage = examScore;
        }
    }
    return percentage;
}
