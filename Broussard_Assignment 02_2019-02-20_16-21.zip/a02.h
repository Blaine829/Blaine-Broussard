#ifndef __A02_H__
#define __A02_H__


int reverseDigits(int number);


#endif
