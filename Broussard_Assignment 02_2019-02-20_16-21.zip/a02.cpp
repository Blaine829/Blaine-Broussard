#include "a02.h"
#include <iostream>
using std::cout;
using std::endl;

int reverseDigits(int number) {
    bool track = false;
    if (number < 0) {
        number = number * -1;
        track = true;
    }
    int num;
    int reverse = 0;
    while (number != 0) {
        num = number % 10;
        number = number / 10;
        reverse = (reverse*10) + num;
    }
    if (track == true) {
        reverse = reverse * -1;
    }
    return reverse;
}
int main() {
    cout << reverseDigits(12345) << endl;
    return 0;
}
