#include <iostream>
#include "a02.h"

using std::cout;
using std::endl;


int main() {
    cout << "123 reversed should be 321    (";
    if (reverseDigits(123) == 321) {
        cout << "SUCCESS";
    } else {
        cout << "FAILURE";
    }
    cout << ")" << endl;

    cout << "-512 reversed should be -215  (";
    if (reverseDigits(-512) == -215) {
        cout << "SUCCESS";
    } else {
        cout << "FAILURE";
    }
    cout << ")" << endl;

    cout << "4 reversed should be 4        (";
    if (reverseDigits(4) == 4) {
        cout << "SUCCESS";
    } else {
        cout << "FAILURE";
    }
    cout << ")" << endl;

    cout << "350 reversed should be 53     (";
    if (reverseDigits(350) == 53) {
        cout << "SUCCESS";
    } else {
        cout << "FAILURE";
    }
    cout << ")" << endl;

    cout << "-9000 reversed should be -9   (";
    if (reverseDigits(-9000) == -9) {
        cout << "SUCCESS";
    } else {
        cout << "FAILURE";
    }
    cout << ")" << endl;


    return 0;
}
