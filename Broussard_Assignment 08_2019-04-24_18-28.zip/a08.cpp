#include <iostream>
#include "a08.h"


using std::cout;
using std::endl;
//*****************************************************************
//                          FUNDAMENTALS
//*****************************************************************

ArrayList mergeLists(ArrayList listA, ArrayList listB) {
    ArrayList m;
    int indexA = 0;
    int indexB = 0;
    while (indexB < listB.size() && indexA < listA.size()) {
        m.append(listA.get(indexA));
        m.append(listB.get(indexB));
        indexB++;
        indexA++;
    }
    if (indexA < listA.size()) {
        while (indexA < listA.size()) {
            m.append(listA.get(indexA));
            indexA++;
        }
    } else if (indexB < listB.size()) {
        while (indexB < listB.size()) {
            m.append(listB.get(indexB));
            indexB++;
        }
    }
    return m;
}

//*****************************************************************
//                          PROFICIENCY
//*****************************************************************

void splitList(ArrayList list, int splitValue, ArrayList& lo, ArrayList& hi) {
    lo.clear();
    hi.clear();
    int length = list.size();
    for (int num = 0; num < length; num++) {
        if (list.get(num) < splitValue) {
            lo.append(list.get(num));
        } else if (list.get(num) >= 5) {
            hi.append(list.get(num));
        }
    }
}

//*****************************************************************
//                            MASTERY
//*****************************************************************

void performOperations(ArrayList& data, ArrayList operations) {
    int size = data.size();
    for (int num = 0; num < operations.size(); num = num + 3) {
        int operation = operations.get(num);
        int first = operations.get(num + 1);
        int second = operations.get(num + 2);
        if (first > size || first < 0 || second > size || second < 0) {
                throw OperationException();
        }
        if (operation == 0) {
                data.set(second, data.get(first));
        } else if (operation == 1) {
                data.set(second, data.get(first) + data.get(second));
        } else if (operation == 2) {
                data.set(second, data.get(first) * data.get(second));
        }
    }
}
