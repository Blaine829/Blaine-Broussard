#include "lists.h"


ArrayList::ArrayList() : numElements(0) { }

int ArrayList::get(int index) const {
    if (index >= 0 && index < numElements) {
        return data[index];
    } else {
        throw IndexOutOfBoundsException();
    }
}

void ArrayList::set(int index, int value) {
    if (index >= 0 && index < numElements) {
        data[index] = value;
    } else {
        throw IndexOutOfBoundsException();
    }
}

void ArrayList::append(int value) {
    if (numElements < ArrayList::CAPACITY) {
        data[numElements] = value;
        numElements++;
    } else {
        throw ListCapacityException();
    }
}

void ArrayList::insert(int index, int value) {
    if (index >= 0 && index <= numElements) {
        if (numElements < ArrayList::CAPACITY) {
            for (int i = numElements - 1; i >= index; i--) {
                data[i + 1] = data[i];
            }
            data[index] = value;
            numElements++;
        } else {
            throw ListCapacityException();
        }
    } else {
        throw IndexOutOfBoundsException();
    }
}

int ArrayList::size() const {
    return numElements;
}

void ArrayList::clear() {
    numElements = 0;
}
