#ifndef __A07_LISTS_H__
#define __A07_LISTS_H__


class IndexOutOfBoundsException { };
class ListCapacityException { };

class ArrayList {
 public:
    // Constructor creates an empty list of integers.
    ArrayList();

    // Returns the list element at the specified index or
    // throws IndexOutOfBoundsException if no such element.
    int get(int index) const;

    // Sets the list element at the specified index to the value or
    // throws IndexOutOfBoundsException if no such element.
    void set(int index, int value);

    // Adds the value to the end of the list if possible or
    // throws a ListCapacityException if the list has reached capacity.
    void append(int value);

    // Inserts the value at the specified index of the list, moving
    // all following elements down to the next index. The index must be
    // between 0 and the current number of elements (inclusive). Otherwise,
    // it throws an IndexOutOfBoundsException. If the list has reached
    // capacity, it throws a ListCapacityException.
    void insert(int index, int value);

    // Returns the current size of the list.
    int size() const;

    // Removes all elements from the list.
    void clear();

 private:
    static const int CAPACITY = 32;
    int data[CAPACITY];
    int numElements;
};


#endif
