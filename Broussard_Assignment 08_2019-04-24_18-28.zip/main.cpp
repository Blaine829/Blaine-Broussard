#include <iostream>
#include "a08.h"

using std::cout;
using std::endl;


int main() {
    int anums[] = {1, 2, 3, 4};
    int bnums[] = {5, 6, 7, 8, 9, 0};
    ArrayList alist;
    for (int i = 0; i < 4; i++) {
        alist.append(anums[i]);
    }
    ArrayList blist;
    for (int i = 0; i < 6; i++) {
        blist.append(bnums[i]);
    }
    ArrayList merge = mergeLists(alist, blist);
    int m[] = {1, 5, 2, 6, 3, 7, 4, 8, 9, 0};
    if (merge.size() == 10) {
        cout << "(SUCCESS)";
        cout << "  Merge list size [10 == " << merge.size() << "]" << endl;
        for (int i = 0; i < 10; i++) {
            cout << ((merge.get(i) == m[i])? "(SUCCESS)" : "(FAILURE)");
            cout << "  merge.get(" << i << ")";
            cout << "  [" << m[i] << " == " << merge.get(i) << "]" << endl;
        }
    } else {
        cout << "(FAILURE)";
        cout << "  Merge list size [10 == " << merge.size() << "]" << endl;
    }
    /*
    int a[] = {8, 6, 7, 5, 3, 0, 9};
    int b[] = {0, 2, 5, 1, 5, 4, 2, 0, 4};
    ArrayList a_list;
    for (int i = 0; i < 7; i++) {
        a_list.append(a[i]);
    }
    ArrayList b_list;
    for (int i = 0; i < 9; i++) {
        b_list.append(b[i]);
    }
    performOperations(a_list, b_list);
    for (int num = 0; num < a_list.size(); num++) {
        cout << a_list.get(num) << endl;
    }
    */
    return 0;
}
