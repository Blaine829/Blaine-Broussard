#ifndef __A08_H__
#define __A08_H__

#include "lists.h"


//*****************************************************************
//                          FUNDAMENTALS
//*****************************************************************

// Return the list representing the merge the two lists. The merge should
// be interleaved so that the first element from listA comes before the
// first element of listB and so on. If the lists are unequal in length,
// the remaining elements of the longer list should be placed at the end
// of the merged list.
//
// For instance, [1, 2, 3, 4] and [5, 6, 7, 8, 9, 0] would merge into
// [1, 5, 2, 6, 3, 7, 4, 8, 9, 0].
ArrayList mergeLists(ArrayList listA, ArrayList listB);


//*****************************************************************
//                          PROFICIENCY
//*****************************************************************

// Split the given ArrayList according to splitValue such that lo contains
// all elements of list that are less than splitValue and hi contains all
// elements of list that are greater-equal to splitValue. Relative position
// is preserved.
//
// For instance, [8, 6, 7, 5, 3, 0, 9] with a split value of 5 would produce
// lo of [3, 0] and hi of [8, 6, 7, 5, 9].
void splitList(ArrayList list, int splitValue, ArrayList& lo, ArrayList& hi);


//*****************************************************************
//                            MASTERY
//*****************************************************************

class OperationException { };

// Perform the specified opterations on the data list. The operations
// list is guaranteed to have a size that is a multiple of 3. Every
// three elements represents a single operation. The first element
// of a triple is the specific operation (0 = move, 1 = add, 2 = multiply).
// The second element is the source data location. The third element is
// the destination data location.
//
// For instance, if the operation triple were (0, 5, 2), then that would
// mean that the integer at index 5 in data would move to replace the
// integer at index 2 in data. Likewise, if the triple were (1, 3, 2),
// then the value at index 3 would be added to the value at index 2 and
// the result would then be stored at index 2 (replacing the previous element).
//
// As a full example, suppose that data were [8, 6, 7, 5, 3, 0, 9].
// Also, suppose the operations were [0, 2, 5, 1, 5, 4, 2, 0, 4].
// Then data would first change to [8, 6, 7, 5, 3, 7, 9] (move @2 to @5),
// then to [8, 6, 7, 5, 10, 7, 9] (add @5 to @4), then to
// [8, 6, 7, 5, 80, 7, 9] (multiply @0 to @4).
//
// If an operation refers to an illegal data location (such as -1 or 9 in
// the example above), an OperationException should be thrown.
void performOperations(ArrayList& data, ArrayList operations);


#endif
